package com.stark.afk;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ShopManager {
    public static class Entry {
        public final ItemStack item;
        public long price;
        public Entry(ItemStack item, long price) { this.item = item; this.price = price; }
    }

    private final AfkPlugin plugin;
    private final File file;
    private final List<Entry> entries = new ArrayList<>();

    public ShopManager(AfkPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "shop.yml");
        load();
    }

    public List<Entry> getEntries() { return entries; }

    private void load() {
        entries.clear();
        if (!file.exists()) return;
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection s = cfg.getConfigurationSection("items");
        if (s == null) return;
        for (String key : s.getKeys(false)) {
            ItemStack it = s.getItemStack(key + ".item");
            if (it != null) entries.add(new Entry(it, s.getLong(key + ".price")));
        }
    }

    public void save() {
        YamlConfiguration cfg = new YamlConfiguration();
        for (int i = 0; i < entries.size(); i++) {
            cfg.set("items." + i + ".item", entries.get(i).item);
            cfg.set("items." + i + ".price", entries.get(i).price);
        }
        try { cfg.save(file); } catch (IOException e) { plugin.getLogger().warning("Could not save shop.yml: " + e.getMessage()); }
    }
}

package com.stark.afk;

import org.bukkit.Location;

/** Region from minY upward (no upper limit). */
public record Region(String name, String world, int minX, int maxX, int minZ, int maxZ, int minY) {
    public boolean contains(Location l) {
        if (l.getWorld() == null || !l.getWorld().getName().equals(world)) return false;
        int x = l.getBlockX(), y = l.getBlockY(), z = l.getBlockZ();
        return y >= minY && x >= minX && x <= maxX && z >= minZ && z <= maxZ;
    }
}
